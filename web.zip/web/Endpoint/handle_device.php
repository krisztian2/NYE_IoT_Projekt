<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

//declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/shared/config.php';

use PhpMqtt\Client\ConnectionSettings;
use PhpMqtt\Client\Exceptions\MqttClientException;
use PhpMqtt\Client\MqttClient;


// Create an instance of a PSR-3 compliant logger. For this example, we will also use the logger to log exceptions.
if(isset($_POST["action"])){
try {
    // Create a new instance of an MQTT client and configure it to use the shared broker host and port.
    $client = new MqttClient(MQTT_BROKER_HOST, MQTT_BROKER_PORT, 'web-publisher', MqttClient::MQTT_3_1, null, null);

    $connectionSettings = (new ConnectionSettings)
    ->setUsername(AUTHORIZATION_USERNAME)
    ->setPassword(AUTHORIZATION_PASSWORD);

    // Connect to the broker without specific connection settings but with a clean session.
    $client->connect($connectionSettings, true);

    // Publish the message 'Hello world!' on the topic 'foo/bar/baz' using QoS 0.
    
    $client->publish('/web/motiondetector/status/1', json_encode(["isAuthorized"=>true,"action"=>$_POST["action"], "userid"=>1]), MqttClient::QOS_AT_MOST_ONCE);

    // Gracefully terminate the connection to the broker.
    $client->disconnect();
    echo json_encode(["msg"=>"Az MQTT Broker szerver megkapta a kérést!"]);
} catch (MqttClientException $e) {
    // MqttClientException is the base exception of all exceptions in the library. Catching it will catch all MQTT related exceptions.
    echo $e->getMessage();
}
}