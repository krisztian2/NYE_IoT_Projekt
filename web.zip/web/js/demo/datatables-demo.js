// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable({
    language: {
      'paginate': {
        'previous': 'Előző',
        'next': 'Következő',
      },
      'info': '_PAGE_ / _PAGES_',
      'lengthMenu': "_MENU_ sor megjelenítése / oldal",
      'search':'Keresés'
    }
  });
});
